<h1>Esteban Llanos - Daniel Victoria<h1>

<h2>Objetivo general del proyecto<h2>

<h4>Se encarga de realizar actas de grado y de tener un control de notas para los estudiantes de posgrado, más concretamente para los estudiantes de maestría en ingeniería de software.<h4>


<h2>Principales funciones del proyecto<h2>

<h3>Calcular nota final<h3>

<h4>Se encarga de sacar la nota final a partir de las notas publicadas por los jueces 1 y 2, además de eso también, se encarga de sacar las notas de los jueces por medio
de los criterios y su valor correspondiente, ya sea del 20% o del 5%, además se dice si el estudiante aprobó o no.<h4>

<h3>Agregar acta<h3>

<h4>Se encarga de preguntar y asignar los valores correspondientes al acta, ya sea el nombre del estudiante, el nombre del director o directora, nombre del jurado, etc.<h4>

<h3>Agregar criterios<h3>

<h4>Se encarga de preguntarle al director o directora de la maestría la rubrica o los criterios a ser evaluados, además de asignarle un valor porcentual.<h4>

<h3>Mostrar Acta<h3>

<h4>Se encarga de mostrarle al secretario o la secretaria las actas que se han realizado hasta el momento de la consulta, el director o loa directora, también puede acceder a esta función.<h4>
